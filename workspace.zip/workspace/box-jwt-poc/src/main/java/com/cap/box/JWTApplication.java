package com.cap.box;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.concurrent.atomic.AtomicInteger;

import com.box.sdk.BoxAPIConnection;
import com.box.sdk.BoxConfig;
import com.box.sdk.BoxDeveloperEditionAPIConnection;
import com.box.sdk.BoxFolder;
import com.box.sdk.BoxItem.Info;
import com.box.sdk.BoxUser;
import com.box.sdk.CreateUserParams;
import com.box.sdk.IAccessTokenCache;
import com.box.sdk.InMemoryLRUAccessTokenCache;

public class JWTApplication {

	static String CONFIGFILE = "C:\\Vikas\\MulesoftWorkspace\\workspace\\BoxMavenProject\\certificate\\config.json";
	static int MAX_CACHE_ENTRIES = 100;
	Reader reader = null; 
	BoxConfig boxConfig = null;
	IAccessTokenCache accessTokenCache = null;
	public JWTApplication() {
		try {
		reader = new FileReader(CONFIGFILE);
		boxConfig = BoxConfig.readFrom(reader);
		accessTokenCache = new InMemoryLRUAccessTokenCache(MAX_CACHE_ENTRIES);
		}catch (Exception e) {e.printStackTrace();}
	}
	public BoxDeveloperEditionAPIConnection getAPIConnection() {
		BoxDeveloperEditionAPIConnection adminClient = null;
		try {
			adminClient = BoxDeveloperEditionAPIConnection.getAppEnterpriseConnection(boxConfig, accessTokenCache);
		}catch(Exception e) {e.printStackTrace();}
		return adminClient;
	}
	
	public BoxDeveloperEditionAPIConnection getAPIConnection(String userId) {
		BoxDeveloperEditionAPIConnection client = null;
		//try {
			client = BoxDeveloperEditionAPIConnection.getAppUserConnection(userId, boxConfig);
		//}catch(Exception e) {e.printStackTrace();}
		return client;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("%%%%%%%%%%%%%%%%%%");
		
		try {
	//Create Connection
			
			JWTApplication jwtapp = new JWTApplication();
		//	BoxDeveloperEditionAPIConnection adminClient = jwtapp.getAPIConnection();
			BoxAPIConnection api = jwtapp.getAPIConnection();

			//Search for existing user using email id
			Iterable<BoxUser.Info> users = BoxUser.getAppUsersByExternalAppUserID(api, "User4@hotmail.com");
			users.forEach((user) -> {
				  System.out.println(user.getID()+"   "+user.getName()+"    "+user.getJobTitle());
				});
			
	// Create new app user
/*		String userName = "User4@hotmail.com";
		String jobTitle = "Lab4 User";
		long spaceAmount = 1073741824;
		CreateUserParams params = new CreateUserParams();
		params.setJobTitle(jobTitle);
		params.setSpaceAmount(spaceAmount);
		params.setExternalAppUserId(userName);
		BoxUser.Info createdUserInfo = BoxUser.createAppUser(api, userName,params);
		System.out.println("Following App User is created for your app");
		System.out.println("User Name         - "+createdUserInfo.getName());
		System.out.println("User Id           - "+createdUserInfo.getID());
		System.out.println("Job Title         - "+createdUserInfo.getJobTitle());
		System.out.println("ExternalAppUserId - "+createdUserInfo.getExternalAppUserId());
*/		
		//Get current service account user
/*		BoxUser user = BoxUser.getCurrentUser(api);
		BoxUser.Info info = user.getInfo();
		System.out.println("******"+info.getLogin()+"    "+info.getExternalAppUserId());
*/
	//Add App user as collaborator to the folder

			
			
/*		Iterable<BoxUser.Info> users = BoxUser.getAllEnterpriseUsers(adminClient);
		AtomicInteger counter = new AtomicInteger(0);
		users.forEach((user) -> {
		  counter.addAndGet(1);
		  System.out.println(user.getID()+"   "+user.getName());
		});
		
		BoxDeveloperEditionAPIConnection client = jwtapp.getAPIConnection("3542808539");

	
		BoxFolder parentFolder = new BoxFolder(client, "0");

		Iterable<Info> childFolders = parentFolder.getChildren();
		childFolders.forEach((childFolder) -> {
			System.out.println("&&&&&&&&"+childFolder.getName());
		});
		
	*/	
		System.out.println("%%%%%%%%%%%%%%%%%%");
		
		}catch(Exception e) {e.printStackTrace();}

	}

}
