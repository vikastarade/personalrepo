package com.cap.poc;

public class CapBoxJWTApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
